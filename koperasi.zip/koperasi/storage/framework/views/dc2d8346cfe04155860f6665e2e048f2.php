<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title', 'value', 'color' => 'gray', 'bg' => 'white']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title', 'value', 'color' => 'gray', 'bg' => 'white']); ?>
<?php foreach (array_filter((['title', 'value', 'color' => 'gray', 'bg' => 'white']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="rounded-xl shadow-md p-4 py-8  w-full max-w-xs border-l-4 border-<?php echo e($color); ?>-500 bg-<?php echo e($bg); ?>">
    <p class="text-sm font-semibold text-<?php echo e($color); ?>-600 uppercase"><?php echo e($title); ?></p>
    <h3 class="text-lg font-bold text-gray-800 mt-1"><?php echo e($value); ?></h3>
</div><?php /**PATH C:\laragon\www\koperasi\resources\views/components/dashboard-card.blade.php ENDPATH**/ ?>