<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', function () {
    return view('home', ['title' => 'Manajemen Anggota & Kolektor']);
});

Route::get('/manajemen', function () {
    return view('manajemen', ['title' => 'Manajemen']);
});

Route::get('/mengelola', function () {
    return view('mengelola', ['title' => 'Mengelola']);
});

Route::get('/laporan', function () {
    return view('laporan', ['title' => 'Laporan', 'posts' => [
        [
            'id' => 1,
            'title' => 'Judul Artikel 1',
            'author' => 'Nelsen',
            'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui animi facilis dolor autem voluptatem quaerat, laboriosam eius mollitia beatae praesentium ab earum reiciendis id tempora iure similique consequuntur repellat unde?'
        ]
    ]]);
});

Route::get('/rekap', function () {
    return view('rekap', ['title' => 'Rekap']);
});