@props(['title', 'value', 'color' => 'gray', 'bg' => 'white'])

<div class="rounded-xl shadow-md p-4 py-8  w-full max-w-xs border-l-4 border-{{ $color }}-500 bg-{{ $bg }}">
    <p class="text-sm font-semibold text-{{ $color }}-600 uppercase">{{ $title }}</p>
    <h3 class="text-lg font-bold text-gray-800 mt-1">{{ $value }}</h3>
</div>