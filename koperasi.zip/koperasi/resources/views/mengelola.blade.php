<x-layout>
  <x-slot:title>{{ $title }}</x-slot>
  <h2 class="text-xl">Mengelola Simpan & Pinjam  </h2>
</x-layout>