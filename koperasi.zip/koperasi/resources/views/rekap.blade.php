<x-layout>
  <x-slot:title>{{ $title }}</x-slot>
  <h2 class="text-xl">Rekap Harian & Bulanan  </h2>
</x-layout>