<x-layout>
  <x-slot:title>{{ $title }}</x-slot>
  
  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
    <x-dashboard-card title="Data Anggota" value="10" color="blue" />
    <x-dashboard-card title="Data Pinjaman" value="Rp. 8,100,000" color="green"/>
    <x-dashboard-card title="Data Angsuran" value="Rp. 6,060,000" color="cyan" />
    <x-dashboard-card title="Data Tabungan" value="Rp. 3,271,000" color="yellow" />
    <x-dashboard-card title="Data Denda" value="Rp. 4,242,000" color="red" />
    <x-dashboard-card title="Data Pengajuan" value="Rp. 2,850,000" color="blue" />
  </div>  
</x-layout>
